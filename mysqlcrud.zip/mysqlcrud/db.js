var mysql = require('mysql');
const express = require('express');
const app =express()
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mca'
});
db.connect(function(error) {
    if (!!error) {
        console.log(error);
    } else {
        console.log('successfull')
    }
});
module.exports = db;