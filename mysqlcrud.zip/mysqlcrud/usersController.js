// const db = require('./db')
// const express = require('express');

// exports.store = async(req, res) => {
//     var form_data = {
//         name: req.body.name,
//         email: req.body.email,
//         position: req.body.position,
//     }

//     db.query('INSERT INTO users set?', form_data, function(err, result) {
//         if (err) {
//             res.json('error', err)
//         } else {
//             res.json('success', 'inserted successfully')
//         }
//     });
// }





// // update
// exports.update = async(req, res) => {
//     var form_data = {
//         name: req.body.name,
//         email: req.body.email,
//         position: req.body.position,
//     }

//     db.update('UPDATE users set? where id' + req.body.id, form_data, function(err, result) {
//         if (err) {
//             req.json('error', err)
//         } else {
//             req.json('success', 'update successfully')
//         }
//     });
// }




// // delete
// exports.delete = async(req, res) => {

//     db.delete('delete from  users where id' + req.body.id, form_data, function(err, result) {
//         if (err) {
//             req.json('error', err)
//         } else {
//             req.json('success', 'delete successfully')
//         }
//     });

// }

// // retrive

// exports.index = async(req, res) => {

//     db.query('select * from users ', function(err, result) {
//         if (err) {
//             req.json('error', err)
//         } else {
//             res.json('success', result)
//         }
//     });

// }

// exports.show = async(req, res) => {
//     db.query('select * from users where is=' + req.params.id, function(err, result) {
//         if (err) {
//             req.json('error', err)
//         } else {
//             res.json('success', result)
//         }
//     });
// }

const db = require('./db');

// Store user
exports.store = async (req, res) => {
    var form_data = {
        name: req.body.name,
        email: req.body.email,
        position: req.body.position,
    };

    db.query('INSERT INTO users SET ?', form_data, function(err, result) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: 'Inserted successfully' });
        }
    });
};

// Update user
exports.update = async (req, res) => {
    var form_data = {
        name: req.body.name,
        email: req.body.email,
        position: req.body.position,
    };

    db.query('UPDATE users SET ? WHERE id = ?', [form_data, req.body.id], function(err, result) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: 'Updated successfully' });
        }
    });
};

// Delete user
exports.delete = async (req, res) => {
    db.query('DELETE FROM users WHERE id = ?', [req.body.id],
        function(err, result) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: 'Deleted successfully' });
        }
    });
};


// Retrieve all users
exports.index = async (req, res) => {
    db.query('SELECT * FROM users', function(err, result) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: result });
        }
    });
};

// Retrieve a single user
exports.show = async (req, res) => {
    db.query('SELECT * FROM users WHERE id = ?', [req.params.id], function(err, result) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: result });
        }
    });
};
