// const express = require('express');
// const userController = require('./usersController');
// var mysql = require('mysql');


// const router = express.Router();
// router.get('/users', userController.index);
// router.get('/users', userController.show);
// router.post('/users', userController.store);
// router.put('/users', userController.update);
// router.delete('/student', userController.destroy);


// module.exports = router;

const express = require('express');
const userController = require('./usersController');  // Make sure the path is correct
const router = express.Router();

router.get('/users', userController.index);
router.get('/users/:id', userController.show);
router.post('/users', userController.store);
router.put('/users/:id', userController.update);

// Make sure the 'destroy' function exists in the controller
router.delete('/users/:id', userController.delete);  // Fix the route if necessary

module.exports = router;
