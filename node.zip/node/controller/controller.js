const Users = require('./../model/model');

exports.index = async (req,res)=>{
    const users =await Users.find()
    res.status(201).json(users);
}

exports.store = async (req,res)=>{
    const data = await Users.create(req.body);
    res.send("Data inserted success")
}

exports.destroy = async (req,res)=>{
    const data = await Users.findByIdAndDelete(req.body._id);
    res.send("data deleted");

}


exports.update = async (req,res)=>{
    const data = await Users.findByIdAndUpdate(req.body._id,req.body,{new:true});
    res.send("data updated");
}
  
