const express = require('express');
const mongoose = require('mongoose');
const route = require('./route/route');
const cors = require('cors')

const connectDb =  async ()=>{
    try { 
        const connection = await mongoose.connect("mongodb+srv://rahulghost:63F19dkql406DrTT@cluster0.fjstzse.mongodb.net/users",{});
        console.log("Mongo connected");

    } catch (error) {
        console.log(error)  
    }
}




const app = express();
app.use(express.json());
connectDb();


app.use('/users',route)



app.listen(1234,()=>{
    console.log("port is running 1234");
})