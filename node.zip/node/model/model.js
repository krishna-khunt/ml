const mongoose = require('mongoose')

const User = new  mongoose.Schema(
    {
        name:{
            type:String,
            required:true,
        },
        rollNo:{
            type:Number,
            required:true,
        }
}
)

const Users = mongoose.model('User',User);

module.exports =  Users;

