const express = require('express');
const controller = require('./../controller/controller')
const app = express()
const router = express.Router();

router.get('/',controller.index);
router.post('/',controller.store);
router.put('/',controller.update);
router.delete('/',controller.destroy);



module.exports = router;
